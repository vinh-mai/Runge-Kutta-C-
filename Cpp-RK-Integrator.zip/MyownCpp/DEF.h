/* ID file: A POINTER */

#include "DEF.h"
#include <iomanip.h>

/* Define file ID */
FILE *fid;

/*====================================================*/
void DEF::intpar()

/* Function intpar sets the parameters to control the
integration of the 1x1 ODE system */
{
    /* Number of ODEs */
    neqn = 1;
    
    /* Number of output points */
    nout = 6;
    
    /* Maximun number of steps in the interval t0 to tf */
    nsteps = 100;
    
    /* Initial final values of independent variable */
    t0 = 0.0;
    tf = 1.0;
    
    /* Error tolerances */
    abserr = pow(10.0, -5.0);
    
    relerr = pow(10.0, -5.0);
    
/* End of intpar */
}

/*====================================================*/
void DEF::initial()

/* Function initial sets the initial condition vector
for the 1x1 ODE problem */
{
    /* Initial condition */
    u0[1] = 1.0;
    
/* End of initial */
}

/*====================================================*/
void DEF::derv(double ut[], double t, double u[])

/* Function derv computes the derivatives vector of the
1x1 ODE problem. */
{
    /* Type variables */
    double alpha, lambda;
    
    /* Problem parameters */
    alpha  = 1.0;
    lambda = 1.0;
    
    /* Derivative vector */
    ut[1] = lambda*exp(-alpha*t)*u[1];
    
/* End of derv */ 
}

/*====================================================*/
void DEF::fprint(int ncase, int neqn, double t,
				 double u[])

/* Function fprint displays the numerical and exact
solutions to the 1x1 ODE problem; this routine is
implemented in the traditional C style. */
{
    /* Type variables */
    double ue[2], diff[2];
    double u0, alpha, lambda;
    
    /* Problem parameters */
    u0     = 1.0;
    alpha  = 1.0;
    lambda = 1.0;
    
    /* Print a heading for the solution at t = 0 */
    if(t <= 0.0)
    {
        /* Label for ODE integrator */
        switch(ncase)
        {
            /* Fixed step classical fourth order RK */
            case 1:
            fprintf(fid, "\n\n rkc4a integrator\n\n");
            break;
            
            /* Variable step clssical fourth order RK */
            case 2:
            fprintf(fid, "\n\n rkc4b integrator\n\n");
            
            /* Fixed step RK Fehlberg 45 */
            case 3:
            fprintf(fid, "\n\n rkf45a integrator\n\n");
            break;
            
            /* Variable step RK Fehlberg 45 */
            case 4:
            fprintf(fid, "\n\n rkf45b integrator\n\n");
            break;
        }
        
        /* Heading */
        fprintf(fid, "\n t u1(num) u1(ex)  diff1\n\n");
    }
    
    /* Analytic solution */
    ue[1] = u0*exp(lambda/alpha*(1.0 - exp(-alpha*t)));

    /* Difference between exact and numerical solutions */
    diff[1] = u[1] - ue[1];

    /* Display the numerical and exact solutions, and
    their difference */
    fprintf(fid, "%10.2f %10.5f %10.5f %13.4e\n\n", t,
    		u[1], ue[1], diff[1]);

/* End of fprint*/
}

/*====================================================*/
void DEF::fprint(ofstream &fout, int ncase, int neqn,
				 double t, double u[])

/* Function fprint displays the numerical and exact 
solutions to the 1x1 ODE problem; this function is
implemented in the C++ style */
{
    /* Type variables */
    double ue[2], diff[2];
    double u0, alpha, lambda;
    
    /* Problem parameters */
    u0     = 1.0;
    alpha  = 1.0;
    lambda = 1.0;
    
    /* Set printing format */
    fout << setiosflags(ios::showpoint|ios::fixed)
    	 << setprecision(7);
    
    /* Print a heading for the solution at t = 0 */
    if(t <= 0.0)
    {
        /* Label for ODE integrator */
        switch(ncase)
        {
            /* Fixed step classical fourth order RK */
            case 1:
            fout << "\n\n rkc4a integrator\n\n";
            break;
            
            /* Variable step clssical fourth order RK */
            case 2:
            fout << "\n\n rkc4b integrator\n\n";
            
            /* Fixed step RK Fehlberg 45 */
            case 3:
            fout << "\n\n rkf45a integrator\n\n";
            break;
            
            /* Variable step RK Fehlberg 45 */
            case 4:
            fout << "\n\n rkf45b integrator\n\n";
            break;
        }
        
        /* Heading */
        fout << endl;
        fout << " t" << setw(18) << "u1 (num) " << setw(11)
             << "u1 (ex)" << setw(10) << "diff" << "\n";
    /* End of t = 0 heading */
    }
    
    /* Analytic solution */
    ue[1] = u0*exp(lambda/alpha*(1.0 - exp(-alpha*t)));
    
    /* Difference between exact and numerical solutions */
    diff[1] = u[1] - ue[1];
    fout << endl;
    
    /* Display the numerical and exact solutions, and
    their difference */
    fout << setw(10) << t << setw(12) << u[1] << setw(12)
         << ue[1] << setw(12) << diff[1];
/* End of fprint */
}

/*====================================================*/
/*                		END							  */
/*====================================================*/
