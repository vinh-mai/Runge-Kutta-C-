#include <iostream>
using namespace std;

class Model
{
	int neqn;
	double y [];
	public:
		Model(double k[], int n)
		{
			neqn = n;
			for(int i=0; i < n; i++)
			{
				y[i] = k[i];
			} 
		}
   		//static
   		 double eq1(){return(2.0);}
   		//static
   		 double eq2(){return(y[0] + y[1]);}
};

/* Model */
const int neqn = 10;
void addition (int (&yt) [neqn], int y [], int t)
{
  for( int i = 0; i < 5; i++)
  {
     yt[i] = y[i] + t;
  }
}

int main ()
{
  int y [5] = {1, 2, 3, 4, 5};
  int yt [10];
  int y1 [5] = {-3,-2, 0, 9, 0};
  int yt1 [10];
  
  addition (yt, y, 1);
  for(int i = 0; i < 5; i++)
  {
    cout << "The result is " << yt[i] << endl;
  }
  
  addition (yt, y1, 1);
  for(int i = 0; i < 5; i++)
  {
    cout << "The result is " << yt[i] << endl;
  }
  
//========================================//

	double y0 [] = {3.0, 9.0};
	Model f(y0, 2);

 
//cout << f.eq1() << endl;
//cout << f.eq2() << endl;
return 0;
}
