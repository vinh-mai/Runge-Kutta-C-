

Compile and run cpp file on window
	Compile
		g++ -g filename.cpp -o filenameoutput -lm
	
	Run
		filenameoutput (in command promt)
		
Compile and run on ubuntu

	Compile
		g++ filename.cpp -o filenameoutput
		
	Run
		./filenameoutput
