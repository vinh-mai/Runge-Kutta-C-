/*

Numerical solution to the 1x1 ODE system by
six integrations.

*/

#include <cmath> //Header file for mathematical operations
#include <iomanip> //Header file for precession
#include <iostream> //Header file for cin & cout
#include <fstream> //Header file for writing the results 
#include "model.h" //Header file for model

using namespace std; //Calling the standard directory


//***************************
/* Main program */

int main ()
{
	/* Type variables */
  	/* ODE integration parameters */
  	
	const int neqn = 2;
	int i, j;
	int nsteps = 100;
	double h, e, ye[]; 
	
	double t0 = 0.0;
	double tf = 1.0;

	/* Initial conditions */
	double y0 []= {0.0, -1.0};

	/* Model */
	Model f(y0, neqn);
	
	/* Open file */
	ofstream myfile;
	myfile.open("results.txt");

	myfile << "t   " << "\t" << "y" << "\t" << "ye" << endl; 
 	myfile << t0 << "   \t"  << y0 << "\t" << y0 << endl;	  	
	
	/* Step size */
	h = (tf - t0)/(float)nsteps;
	cout << "Step size: " <<  h << endl;
	
	/* nsteps rkc4 steps */
	for(i = 1; i <= nsteps; i++)
	{
	 	/* Type variables */
    	double yb, tb, ye, y4, y5;
    	double k1, k2, k3, k4, k5, k6;
    	int j;
    
		/* Derivative vector at initial (base) point */
			
		/* k1; stepping for k2 */
//		for(j = 1; j <= neqn; j++)
//		{
		yb = y0;
		tb = t0;

		/* k1; stepping for k2 */
		
		k1 = h*f(yb, tb);


	
		/* k2; stepping for k3 */
//		for(j = 1; j <= neqn; j++)
//		{

		k2 = h*f(yb + (0.25)*k1,
				 tb + (0.25)*h);

	
		/* k3; stepping for k4 */
//		for(j = 1; j <= neqn; j++)
//		{

    	k3 = h*f(yb + (3.0/32.0)*k1
    				+ (9.0/32.0)*k2,
    			 tb + (3.0/8.0)*h);
//	    if( i <= m){cout << "k3 " << k3/h << endl;}
	    
//		}
	

		/* k4; second and fourth order step; error estimate;
		 error correction */
	 
//		for(j = 1; j <= neqn; j++)
//		{



		    k4 = h*f(yb + (1932.0/2197.0)*k1
    					- (7200.0/2197.0)*k2
    					+ (7296.0/2197.0)*k3,
		    		 tb + (12.0/13.0)*h);
//		    if( i <= m){cout << "k4 " << k4/h << endl;}
//			{
		    k5 = h*f(yb + (439.0/216.0)*k1
		    	   		- (8.0)*k2
		    	   		+ (3680.0/513.0)*k3
		           		- (845.0/4104.0)*k4,
		             tb + h);
//		    if( i <= m){cout << "k5 " << k5/h << endl;}
		    
		    
		    k6 = h*f(yb - (8.0/27.0)*k1
		    	   		+ (2.0)*k2
		    	   		- (3544.0/2565.0)*k3
		           		+ (1859.0/4104.0)*k4
		           		- (11.0/40.0)*k5,
		           	 tb + (0.5)*h);
//		    if( i <= m){cout << "k6 " << k6/h << endl;}
		
		    
		    /* Fourth-order RK method*/
		    y4 = yb + (25.0/216.0)*k1
		    		+ (1408.0/2565.0)*k3
		            + (2197.0/4101.0)*k4
		            - (1.0/5.0)*k5;
		    
		    /* Fifth-order RK method */
		    y5 = yb + (16.0/135.0)*k1
		    		+ (6656.0/12825.0)*k3
		            + (28561.0/56430.0)*k4
		            - (9.0/50.0)*k5
		            + (2.0/55.0)*k6;
		            
		    y0 = y5;
		    
		    //cout << y0 << endl;
		    //e = y0 - ye; 

			t0 = tb + h;
			
			ye = (1.0/3.0)*t0 - (1.0/9.0);
	    	
		 	myfile << t0 << "\t"  << y0 << "\t" << ye << endl;	
		}

 
	/* Close file */
	myfile.close();
	
/* End of main */
return 0;
}

		
	
	
