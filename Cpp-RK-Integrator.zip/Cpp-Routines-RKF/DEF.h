/*
 
 Definition of functions intpar, initial, derv, printf
 for the 1x1 ODE system
 
*/

/* Include headers */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <iomanip.h>
#include<MOL.h>

/* Type variables as extern (global) */
extern FILE *fid;

class DEF:public MOL
{
    public:
	
	/* Integration parameters */
    void intpar();
	
	/* Initial conditions */
    void initial();
	
	/* Derivative vector */
    void derv(double ut[], double t, double u[]);
    
    /* Output */
    void fprint(int ncase, int neqn, double t, double u[]);
    
    void fprint(ofstream &fout, int ncase, int neqn,
                double t, double u[]);

};
