#include "DEF.h"
#include "Euler.h"

double Euler::euler2a(int neqn, double t0, double tf,
                      double u[], doubleu0[], int nsteps)
/*

Function euler2a computes an ODE solution by the fixed
step modified Euler method for a series of points along
the solution by repeatedly calling function sseuler for
a single modified Euler step.

Argument list

	neqn	number of first order ODEs
	
	t0		initial value of independent variable
	
	tf		final value of independent variable
	
	u0		initial conditions vector of length neqn
	
	nsteps	number of modified Euler steps
	
	u		ODE solution vector of length neqn after
			nsteps steps

*/

{
	/* Type variable */
    double e[SIZE];
    double h, t;
    int i, j;
	
	/* Integration step */
    h = (tf - t0)/nsteps;
	
	/* nsteps modified Euler steps */
	for(i=1; i <= nsteps; i++)
	{
	  	/* Single modified Euler step */
     	t = sseuler(neqn, t0, u0, h, u, e);
	
		/* Reset bas point values for next modified Euler step */
		for(j=1; j <= neqn; j++)
		{
		  	u0[j] = u[j];
		}
		t0 = t;
		/* End for */
	}
	  
	return 0;
/* End of euler2a */
};

/**************************/
/*--------euler2b---------*/
/*------------------------*/

double Euler::euler2b(int neqn, double t0, double tf,
                      double u[], double u0[], int nsteps,
                      double abserr, double relerr)

/*

Function euler2b computes an ODE solution by the variable step modified Euler method for a series of points along the solution by repeatedly calling function sseuler for a single modified Euler step. The truncation error is estimated along the solution to adjust the integration step according to a specified error tolerance.

Argument list

  neqn		number of first order ODEs
  
  t0 		initial value of independent variable
  	
  tf		final value of independent variable
  
  u0		initial condition vector of length neqn
  
  nsteps	number of modified Euler steps
  
  u			ODE solution vector of length neqn after nsteps steps
  
*/

{
	/* Type variable */
    double h, hmin, t;
    int i,j , nfin1;
    double e[SIZE];
	
	/* Integration step */
	h = (tf - t0)/8.0;
	
	/* Minimum allowable step */
	hmin = (tf - t0)/(float)(nsteps);
	
	/* Start integration */
	t = t0;
	
	/* While independent variable is less than the final */
	while(t <= tf*0.999)
	{
	  	/* If the next step along the solution will go past
	  	the final value of the independent variable, set the
	  	step to the remaining distance to the final value */
	  	if((t + h) > tf)
	  	{
	  	  	h = tf - t;
	  	}
	  	  
	  	/* Single modified Euler step */
	  	t = sseuler(neqn, t0, u0, h, u, e);
	  	
	  	/* Flag for the end of the integration */
	  	nfin1 = 1;
	  	
	  	/* Check if any of the ODEs have violated the error criterion */
	  	for(i=1; i <= neqn; i++)
	  	{
            if(fabs(e[i]) > (fabs(u[i])*relerr + abserr))
	  	  	{
	  	  	    /* Error violation, so integration is incomplete.
	  	  	    Reduce integration step because of error violation
	  	  	    and repeat integration from base point */
	  	  	    nfin1 = 0;
	  	  	    h = h/2.0;
	  	  	    
	  	  	    /* If the current step is less than the minimum 
	  	  	    allowable step, set the step to the minimum allowable 
	  	  	    value and continue integration from new base point */
	  	  	    if(h < hmin)
	  	  	    {
	  	  	        h = (float) hmin;
	  	  	        nfin1 = 1;
	  	  	    }
	  	  	    break;
	  	  	}
	  	}
	  	  
	  /* If there is no error violation, continue the integration
	  from the new base ppoint */
	  if(nfin1 == 1)
	  {
	      for(i = 1; i <= neqn; i++)
	      {
	          u0[i] = u[i];
	      }
	      t0 = t;
	        
	      /* Test if integration step can be increase */
	      for(i = 1; i <= neqn; i++)
	      {
	          if(fabs(e[i]) > ((fabs(u[i])*relerr + abserr)/4.0))
	          {
	              /* Integration step cannot be increase */
	              nfin1 = 0;
	              break;
	           }
	       }
	          
	      /* Increase integration step */
	      if(nfin1 == 1)
	      {
	          h = h*2.0;
	      }
	        
	    /* End if */
	    }
	 
	/* End while */
	}
return 0;

/* End of euler2b */	
}

/****************************/
/*-------sseuler------------*/
/*--------------------------*/

double Euler::sseuler(int neqn, double t0, double u0[],
                      double h, double u[], double e[])

/*

 Function sseuler computes an ODE solution by the modified
 Euler  method for one step along the solution (by calls to
 derv to define the ODE derivative vector). It also estiamtes
 the truncation error of the solution, and applies this estimate
 as a correction to the solution vector.

Argument list

  neqn		number of first order ODEs
  
  t0 		initial value of independent variable
  	
  h			integration step
  
  u0		initial condition vector of length neqn
  
  t			independent variable
  
  u			ODE solution vector of length neqn after one modified
  			EUler step
  e			estimate of truncation error of the solution vector

*/

{
    /* Type variable */
    double ut0[SIZE], ut[SIZE];
    double t;
    int j;
  
    /* Derivative vector at the initial (base) point */
    derv(ut0, t0, u0);
  
    /* First order (Euler) step */
    for(j = 1; j <= neqn; j++)
    {
        u[j] = u0[j] + ut0[j]*h;
    }
    t = t0 + h;
  
    /* Derivative at advance point */
    derv(ut, t, u);
  
    /* Second order (modified Euler) step */
    for(j = 1; j <= neqn; j++)
    {
        /* Truncation error estimate */
        e[j] = (ut[j] - ut0[j])*h/2.0;
      
        /* Second order (modified Euler) solution vector */
        u[j] = u[j] + e[j];
    }
return t;
  
/* End of sseuler */
}

/*===================================*/

/* 

	Routines for the Euler ODE Integration

*/

class Euler:public DEF
{
	public:
	
	double euler2a(int neqn, double t0, double tf, double u[],
	               double u0[], int nsteps);
	
	double euler2b(int neqn, double t0, double tf, double u[],
	               double u0[], int nsteps, double abserr,
	               double relerr);
	
	double sseuler(int neqn, double t0, double u0[], double h,
	               double u[], double e[]);
};

      
		
	
	
