#include "DEF.h"
#include "RK.h"

double RK::rkc4a(int neqn, double t0, double tf,
                 double u[], double u0[], int nsteps)

/*

  Function rkc4a computes an ODE solution by the fixed step
  classical fourth order RK method for a series of points
  along the solution by repeatedly calling function ssrkc4
  for a single classical fourth order RK step.

  Argument list

	neqn	 number of first order ODEs

	t0		 initial value of independent variable

	tf		 final value of independent variable

	u0 		 initial condition vector of length neqn

	nsteps	 number of rkc4 steps
	
	u		 ODE solution vector of length neqn after
			 nsteps steps
			 
*/
{
	/* Type variables */
	int i, j;
	double t, h, e[SIZE];
	
	/* Integration step */
	h = (tf - t0)/(float)nsteps;
	
	/* nsteps rkc4 steps */
	for(i = 1; i <= nsteps; i++)
	{
	    /* Single rkc4 step */
	    t = ssrkc4(neqn, t0, u0, h, u, e);
	
	    /* Reset base point values for next rkc4 step */
	    for(j = 1; j <= neqn; j++)
	    {
	        u0[j] = u[j];
	    }
	    t0 = t;
	}
	
return 0;

/* End of rkc4a */
}


/*=============================================================*/

double RK::rkc4b(int neqn, double t0, double tf,
                 double u[], double u0[], int nsteps,
                 double abserr, double relerr)
                 
/*

  Function rkc4b computes an ODE solution by a variable
  step classical fourth order RK method for a series of
  points along the solution by repeatedly calling function
  ssrkc4 for a single classical fourth order RK step. The
  truncation error is estimated along the solution to
  adjust the integration step according to a specified
  error tolerance.

  Argument list

	neqn	 number of first order ODEs
	
	t0		 initial value of independent variable
	
	tf		 final value of independent variable
	
	u0		 initial condition vector of length neqn
	
	nsteps	 maximum number of rkc4 steps
	
	abserr	 absolute error tolerance
	
	relerr	 relative error tolerance
	
	u		 ODE solution vector of length neqn after
			 nsteps steps

*/
{
    /* Type variables */
    double h, hmin, t, e[SIZE];
    int nfin1, i;
    
	/* Integration step */
	h = (tf - t0)/2.0;
	
	/* Minimum allowable step */
	hmin = (tf - t0)/(float)nsteps;
	
	/* Start integration */
	t = t0;
	
	/* While independent variable is less than the final
	value, continue the integration */
	while(t <= (tf*0.999))
	{
	  /* If the next step along the solution will go past
		the final value of the independent variable, set the
		step to the remaining distance to the final value */
        if((t + h) > tf)
        {
            h = tf - t;
        }
        
        /* Single rkc4 step */
        t = ssrkc4(neqn, t0, u0, h, u, e);
        
        /* Flag for the end of the integration */
        nfin1 = 1;
        
        /* Check if any of the ODEs have violated the 
        error criterion */
        for(i = 1; i <= neqn; i++)
        {
            if(fabs(e[i]) > (fabs(u[i])*relerr + abserr))
            {
                /* Error violation, so integration is
				incomplete. Reduce integration step because
				of error violation and repeat integration
				from base point */
                nfin1 = 0;
                h = h/2.0;
                
                /* If the current step is less than the
				minimum allowable step, set the step to the
				minimum allowable value and continue
				integration from new base point */
				if(h < hmin)
				{
				    h = hmin;
				    nfin1 = 1;
				}
				break;
			}
		}
	
		/* If there is no error violation, continue the
		integration from the new base point */
        if(nfin == 1)
        {
            for(i=1; i <= neqn; i++)
            {
                u0[i] = u[i];
            }
            t0 = t;
        
            /* Test if integration step can be increased */
            for(i = 1; i <= neqn; i++)
            {
                if(fabs(e[i]) > ((fabs(u[i])*relerr + abserr)/16.0))
                {
                    /* Integration step cannot be increased */
                    nfin1 = 0;
                    break;
                }
            }
        
            /* Increase integration step */
            if(nfin1 == 1)
            {
                h = h*2.0;
            }
        
        /* End if */
        }
        
    /* End while */
    }

return 0;

/* End of rkc4b */
}

/*====================================================*/

double RK::ssrkc4(int neqn, double t0, double u0[],
                 double h, double u[], double e[])
                 
/*

  Function ssrkc4 computes an ODE solution by the classical
  fourth order RK method for one step along the solution
  (by calls to derv to define the ODE derivative vector).
  It also estimates the truncation error of the solution,
  and applies this estimate as a correction to the solution
  vector.

  Argument list

	neqn	 number of first order ODEs
	
	t0		 initial value of independent variable
		
	u0		 initial condition vector of length neqn
	
	h 		 integration step
	
	t		 independent variable
	
	relerr	 relative error tolerance
	
	u		 ODE solution vector of length neqn after
			 nsteps steps
			 
	e 		 estimate of truncation error of the
			 solution vector

*/
{
    /* Type variables */
    double ut0[SIZE], ut[SIZE], u4[SIZE];
    double t, k1[SIZE], k2[SIZE], k3[SIZE], k4[SIZE];
    int j;
    
	/* Derivative vector at initial (base) point */
	derv(ut0, t0, u0);
	
	/* k1; stepping for k2 */
	for(j = 1; j <= neqn; j++)
	{
	    k1[j] = h*ut0[j];
	    u[j]  = u0[j] + 0.5*k1[j];
	}
	t = t0 + 0.5*h;
	
	/*Derivative vector at next RK point */
	derv(ut, t, u);
	
	/* k2; stepping for k3 */
	for(j = 1; j <= neqn; j++)
	{
	    k2[j] = h*ut[j];
	    u[j]  = u0[j] + 0.5*k2[j];
	}
	t = t0 + 0.5*h;
	
	/* Derivative vector at next RK point */
	derv(ut, t, u);
	
	/* k3; stepping for k4 */
	for(j = 1; j <= neqn; j++)
	{
	    k3[j] = h*ut[j];
	    u[j]  = u0[j] + h*k3[j];
	}
	t = t0 + h;
	
	/* Derivative vector at next RK point */
	derv(ut, t, u);
	
	/* k4; second and fourth order step; error estimate;
	 error correction */
	 
	for(j = 1; j <= neqn; j++)
	{
	    k4[j] = h*ut[j];
	    u[j]  = u0[j] + k2[j];
	    u4[j] = u0[j] + (1.0/6.0)*(k1[j] + 2.0*k2[j]
	                + 2.0*k3[j] + k4[j]);
	    e[j] = u4[j] - u[j];
	    u[j] = u[j] + e[j];
	}
	t = t0 + h;
	
return t;

/* End of ssrkc4 */
}

/*====================================================*/

double RK::rkf45a(int neqn, double t0, double tf,
			   	  double u[], double u0[], int nsteps)
			   	  
/*
 Function rkf45a computes an ODE solution by the fixed
 step RK Fehlberg 45 RK method for a series of points
 along the solution by repeatedly calling function
 ssrkf45 for a single RK Fehlberg 45 step.
 
 Argument list
 
 	neqn		number of first order ODEs
 	
 	t0			initial value of independent variable
 	
 	tf			final value of independet variable
 	
 	u0			initial condition vector of length neqn
 	
 	nsteps		number of rkf45 steps
 	
 	u			ODE solution vector of length neqn after
 				nsteps steps
 				
*/
{
	/* Type variables */
	double t, h, e[SIZE];
	int i, j;
	
	/* Integration step */
	h = (tf- t0)/(float) nsteps;
	
	/* nsteps rkf45 steps */
	for(i = 1; i <= nsteps; i++)
	{
	    /* Single rkf45 step */
	    t = ssrkf45(neqn, t0, u0, h, u, e);
	    
	    /* Reset base point values for next rkf45 step */
	    for(j = 1; j <= neqn; j++)
	    {
	    	u0[j] = u[j];
	    }
	    t0 = t;
	/* End for */
	}
	
return 0;

/* End of rkf45a */
}

/*====================================================*/

double RK::rkf45b(int neqn, double t0, double tf,
			   	  double u[], double u0[], int nsteps,
			   	  double ebserr, double relerr)
			   	  
/*
 Function rkf45b computes an ODE solution by a variable
 step classical RK Fehlberg 45 RK method for a series of
 points along the solution by repeatedly calling function
 ssrkf45 for a single RK Fehlberg 45 step. The truncation
 error is estimated along the solution to adjust the
 integration step according to a specified error tolerance.
 
 Argument list
 
 	neqn		number of first order ODEs
 	
 	t0			initial value of independent variable
 	
 	tf			final value of independet variable
 	
 	u0			initial condition vector of length neqn
 	
 	nsteps		number of rkf45 steps
 	
 	abserr		absolute error tolerance
 	
 	relerr		relative error tolerance
 	
 	u			ODE solution vector of length neqn after
 				nsteps steps
 				
*/
{
	/* Type variables */
	double t, h, hmin, t, e[SIZE];
	int i, nfin1;
	
	/* Integration step */
	h = (tf - t0)/2.0;
	
	/* Minimum allowable step */
	hmin = (tf - t0)/(float) nsteps;
	
	/* Start integration */
	t = t0;
	
	/* While independent variable is less than the
	final value, continue the integration */
	while(t <= (tf*0.999))
	{
	    /* If the next step along the solution will go
	    past the final value of the independent variable,
	    set the step to the remaining distance to the
	    final value */
	    if ((t + h) > tf)
	    {
	        h = tf - t;
	    }
	    
	    /* Single rkf45 step */
	    t = ssrkc4(neqn, t0, u0, h, u, e)
	    
	    /* Flag for the end of the integration */
	    nfin1 = 1;
	    
	    /* Check if any of the ODEs have violated the
	    error criterion */
	    for(i = 1; i <= neqn; i++)
	    {
	        if(fabs(e[i]) > (fabs(u[i])*relerr + abserr))
	        {
	            /* Error violation, so integration is
	            incomplete. Reduce integration step
	            because of error violation and repeat
	            integration from base point */
	            nfin1 = 0;
	            h = h/2.0;
	            
	            /* If the current step is less than the
	            minimum allowable step, set the step to
	            the minimum allowable value and continue
	            integration from new base point */
	            if(h < hmin);
	            {
	                h = hmin;
	                nfin1 = 1;
	            }
	            break;
	        }
	    }
	    
	    /* If there is no error violation, continue the
	    integration from the new base point */
	    if( nfin1 == 1)
	    {
	        for(i = 1; i <= neqn; i++)
	        {
	            u0[i] = u[i];
	        }
	        t0 = t;
	        
	        /* Test if integration step can be increased */
	        for(i = 1; i <= neqn; i++)
	        {
	            if(fabs(e[i])> ((fabs(u[i])*relerr +
	                             abserr)/32.0))
	            {
	                /* Integration step cannot be increased */
	                nfin1 = 0;
	                break;
	            }
	        }
	        
	        /* Increase integration step */
	        if(nfin1 == 1)
	        {
	            h = h*2.0;
	        }
	    /* End of if */
	    }
	
	/* End of while */    
	}

return 0;

/* End of rkf45b */
}

/*====================================================*/

double RK::ssrkf45(int neqn, double t0, double u0[],
			   	  double h, double u[], double e[])
			   	  
/*
 Function ssrkf45 computes an ODE solution by a the RK
 Fehlberg 45 method for one step along the solution
 (by call derv to define the ODE derivative vector).
 It also estimates the truncation error of the solution,
 and applies this estimate as a correction to the
 solution vector.
  
 Argument list
 
 	neqn		number of first order ODEs
 	
 	t0			initial value of independent variable
 	
 	u0			initial condition vector of length neqn
 	
 	h			integration step
 	
 	t			independent variable
 	
 	u			ODE solution vector of length neqn after
 				one rkf45 step
 				
	e			estimate of truncation error of the
				solution vector
 				
*/
{
	/* Type variables */
	double t, ut0[SIZE], ut[SIZE], u5[SIZE];
	
	double k1[SIZE], k2[SIZE], k3[SIZE], k4[SIZE],
		   k5[SIZE], k6[SIZE];
	int j;
	
	/* Derivative vector at initial (base) point */
	derv(ut0, t0, u0);
	
	/* k1; stepping for k2 */
	for(j = 1; j <= neqn; j++)
	{
	    k1[j] = h*ut0[j];
	    
	    u[j]  = u0[j] + 0.25*k1[j];
	    
	}
	t = t0 + 0.25*h;
	
	/* Derivative vector at next RK point */
	derv(ut, t, u);
	
	/* k2; stepping for k3 */
	for(j = 1; j <= neqn; j++)
	{
	    k2[j] = h*ut[j];
	    
	    u[j]  = u0[j] + (3.0/32.0)*k1[j]
	                  + (9.0/32.0)*k2[j];
	}
	t = t0 + (3.0/8.0)*h;
	
	/* Derivative vector at next RK point */
	derv(ut, t, u);
	
	/* k3; stepping for k4 */
	for(j = 1; j <= neqn; j++)
	{
	    k3[j] = h*ut[j];
	    
	    u[j]  = u0[j] + (1932.0/2197.0)*k1[j]
	                  - (7200.0/2197.0)*k2[j]
	                  + (7296.0/2197.0)*k3[j];
	}
	t = t0 + (12.0/13.0)*h;
	
	/* Derivative vector at next RK point */
	derv(ut, t, u);
	
	/* k4; stepping for k5 */
	for(j = 1; j<= neqn; j++)
	{
	    k4[j] = h*ut[j];
	    
	    u[j]  = u0[j] + ( 439.0/216.0)*k1[j]
	                  - (         8.0)*k2[j]
	                  + (3680.0/513.0)*k3[j]
	                  - (845.0/4104.0)*k4[j];
	}
	t = t0 + h;
	
	/* Derivative vector at next RK point */
	derv(ut, t, u);
	
	/* k5; stepping for k6 */
	for(j = 1; j <= neqn; j++)
	{
	    k5[j] = h*ut[j];
	    
	    u[j]  = u0[j] - (     8.0/27.0)*k1[j]
	                  + (          2.0)*k2[j]
	                  - (3544.0/2565.0)*k3[j]
	                  + (1859.0/4104.0)*k4[j]
	                  + (    11.0/40.0)*k5[j];
	}
	t = t0 + 0.5*h;
	
	/* Derivative vector at next RK point */
	derv(ut, t, u);
	
	/* k6; fourth and fifth order step; error estimate;
	error correction */
	for(j = 1; j <= neqn; j++)
	{
	    k6[j] = h*ut[j];
	    
	    u[j]  = u0[j] + (   25.0/216.0)*k1[j]
	                  + (1408.0/2565.0)*k3[j]
	                  + (2197.0/4104.0)*k4[j]
	                  - (      1.0/5.0)*k5[j];
	                  
	    u5[j] = u0[j] + (     16.0/135.0)*k1[j]
	                  + ( 6656.0/12825.0)*k3[j]
	                  + (28561.0/56430.0)*k4[j]
	                  - (       9.0/50.0)*k5[j]
	                  + (       2.0/55.0)*k6[j];
	    e[j]  = u5[j] - u[j];
	    
	    u[j]  = u[j] + e[j];
	}
	t = t0 + h;

return t;

/* End of ssrkf45 */
}

/*====================================================*/

/*

	Routines for the RK Integration

*/

class RK::public DEF
{
    public:
        double rkc4a(int neqn, double t0, double tf,
        			 double u[], double u0[], int nsteps);
        
        double rkc4b(int neqn, double t0, double tf,
                     double u[], double u0[], int nsteps,
                     double abserr, double relerr);
        
        double ssrkc4(int neqn, double t0, double u0[],
                      double h, double u[], double e[]);
        
        double rkf45a(int neqn, double t0, double tf,
                      double u[], double u0[], int nsteps);
        
        double rkf45b(int neqn, double t0, double tf,
                      double u[], double u0[], int nsteps,
                      double abserr, double relerr);
        
        double ssrkf45(int neqn, double t0, double u0[],
                       double h, double u[], double e[]);

};

/*====================================================*/
 
 


	
