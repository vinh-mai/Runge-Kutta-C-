/*
 
 Definition of functions intpar, initial, derv, printf
 for the 1x1 ODE system
 
*/

/* Include headers */
//#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <iomanip.h>
#include<MOL.h>

/*

Define the common (global) variables for the
1x1 ODE problem

*/
		
/* Maximum (default) number of ODEs */
#define SIZE 500

class MOL
{
    public:
	
	/* Variables for ODE integration */
	
    int neqn, nout, nsteps;
	
	double t0, tf, abserr, relerr;
	
	double u[SIZE], u0[SIZE], e[SIZE];
}; 
	
