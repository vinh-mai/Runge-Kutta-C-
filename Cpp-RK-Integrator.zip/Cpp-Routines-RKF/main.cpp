/*

Numerical solution to the 1x1 ODE system by
six integrations.

*/

// Header file for mathematical operations
#include <math.h>
#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>

// Include files for the integrations
#include "ode1x1.h"
#include "Euler.h"
#include "RK.h"

// Calling the standard directory
//using namespace std;

//***************************
/* Main program */

void main()
{
	/* Type variables */
    double tp;
    int i, j, ncase;
	
	/* Derive objects */
	/* DEF, Euler, and RK are a class */
    DEF o1;
    Euler  e1;
    RK rk;
	
	/* Open a file for output */
    ofstream fout("ode1x1cpp.out", ios::out};
	
	/* Step through six integration */
    for(ncase=1; ncase <= 2; ncase++)
    {
	  	/* ODE integration parameters */
        o1.intpar();
	  	
	  	/* Initial conditions */
        o1.initial();
	  	
	  	/* Output interval */
        tp = o1.tf - o1.t0;
	  	
	  	/* Set through nout grid points */
        for(j=1; j <= o1.nout; j++)
	  	{
	  	  	/* Print solution */
	  	  	o1.fprint(fout, ncase, o1.neqn, o1.t0, o1.u0);
	  	  	
	  	  	/* Select ODE integrator */
	  	  	switch(ncase)
	  	  	{
	  	  	  	/* Fixed step modified Euler integrator */
	  	  	  	case 1:
	  	  	  	e1.euler2a(o1.neqn, o1.t0, o1.tf, o1.u, o1.u0,
	  	  	  	           o1.nsteps);
	  	  	  	break;
	  	  	  	
	  	  	  	/* Variable step modified Euler integrator */
	  	  	  	case 2:
	  	  	  	e1.euler2b(o1.neqn, o1.t0, o1.tf, o1.u, o1.u0,
	  	  	  	           o1.nsteps, o1.abserr, o1.relerr);
	  	  	  	break;
	  	  	  	
	  	  	  	/* Fixed step classical fourth order RK integrator */
	  	  	  	case 3:
	  	  	  	rk.rkc4a(o1.neqn, o1.t0, o1.tf, o1.u, o1.u0,
	  	  	  	         o1.nsteps);
	  	  	  	break;
	  	  	  	
	  	  	  	/* Variable step classical fourth order RK
	  	  	  	 integrator */
	  	  	  	 case 4:
	  	  	  	 rk.rkc4b(o1.neqn, o1.t0, o1.tf, o1.u, o1.u0,
	  	  	  	          o1.nsteps, o1.abserr, o1.relerr);
	  	  	  	 break;
	  	  	  	 
	  	  	  	 /* Fixed step RK Fehlberg (RKF45) integrator */
	  	  	  	 case 5:
	  	  	  	 rk.rkf45a(o1.neqn, o1.t0, o1.tf, o1.u, o1.u0,
	  	  	  	           o1.nsteps);
	  	  	  	 break;
	  	  	  	 
	  	  	  	 /* Variable step RK Fehlberg (RKF45) integrator */
	  	  	  	 case 6:
	  	  	  	 rk.rkf4b(o1.neqn, o1.t0, o1.tf, o1.u, o1.u0,
	  	  	  	          o1.nsteps, o1.abserr, o1.relerr);
	  	  	  	 break;
	  	  	  	 
	  	  	}
	  	  	/* Advance solution */
	  	  	o1.t0  = o1.tf;
	  	  	o1.tf += tp;
	  	  	for(i=1; i<= o1.neqn; i++)
	  	  	{
	  	  	  	o1.u0[i] = o1.u[i];
	  	  	}
	  	/* Next output */
	  	}
	  	
	 /* Next integrator */
	 }
	 
  /* Complete solution computed. Close output filr */
  fout << endl;
  fout.close();

/* End of main */
}

		
	
	
